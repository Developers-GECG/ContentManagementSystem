<?php

require_once("Functions.php");

$functions = new Functions();

//Provide your database login details here:
//hostname, user name, password, database name and table name
//note that the script will create the table (for example, fgusers in this case)
//by itself on submitting register.php for the first time
$functions->InitDB(/*hostname*/'127.0.0.1:3306',
                      /*username*/'root',
                      /*password*/'root',
                      /*database name*/'api');
$functions->SetRandomKey("acnvi69ndm85kvn");
?>
