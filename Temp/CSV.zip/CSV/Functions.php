<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Functions
 *
 * @author Rajat
 */
require_once 'config.php';

class Functions {
    var $dbname;
    var $host;
    var $username;
    var $password;
    var $tablename;
    var $connection;
    var $error_message;
    var $rand_key;
    
    function InitDB($hostname, $uname, $pwd, $database){
        $this->host = $hostname;
        $this->username = $uname;
        $this->password = $pwd;
        $this->dbname = $database;
    }
    
    function ConnectToDB($t_name){
		$this->tablename=$t_name;
        $this->connection = mysql_connect($this->host, $this->username, $this->password);
        if (!$this->connection){
            die("Error in Connection : ".mysql_error());
            return false;
        }
        mysql_select_db($this->dbname, $this->connection);
        return true;
    }
    
    function Register(){
        $formvars = array(
			'name'=>$_POST['name'],
			'ph_no'=>$_POST['ph_no'],
			'email_id'=>$_POST['email_id'],
			'address'=>$_POST['address'],
			'dept_name'=>$_POST['dept_name'],
			'dob'=>$_POST['dob'],
			'doj'=>$_POST['doj'],
			'designation'=>$_POST['designation'],
			'role'=>$_POST['role'],
			'password'=>$_POST['password']);
        if(!$this->SaveToDB($formvars)){
            die("Error :".$this->error_message);
            return false;
        }
        return true;
    }
    
    function Login()
    {
        if(empty($_POST['email_id']))
        {
            $this->HandleError("UserName is empty!");
            return false;
        }
        
        if(empty($_POST['password']))
        {
            $this->HandleError("Password is empty!");
            return false;
        }
        
        $email_id = trim($_POST['email_id']);
        $password = trim($_POST['password']);
        
        if(!isset($_SESSION)){ session_start(); }
        if(!$this->CheckLoginInDB($email_id,$password))
        {
            return false;
        }
        $_SESSION[$this->GetLoginSessionVar()] = $email_id;
        
        return true;
    }
    
    function CheckLogin()
    {
         if(!isset($_SESSION)){ session_start(); }

         $sessionvar = $this->GetLoginSessionVar();
         
         if(empty($_SESSION[$sessionvar]))
         {
            return false;
         }
         return true;
    }
    
    function CheckLoginInDB($email_id,$password)
    {
        if(!$this->ConnectToDB('staff'))
        {
            $this->HandleError("Database login failed!");
            return false;
        }          
        //$email_id = $this->$email;
        //$pwdmd5 = md5($password);
        $qry = "Select name from $this->tablename where email_id='$email_id' and password='$password'";
        
        $result = mysql_query($qry,$this->connection);
        
        if(!$result || mysql_num_rows($result) <= 0)
        {
            $this->HandleError("Error logging in. The username or password does not match");
            return false;
        }
        
        $row = mysql_fetch_assoc($result);
        
        
        $_SESSION['name_of_user']  = $row['name'];
        $_SESSION['email_of_user'] = $email_id;
        
        return true;
    }
    
    function checkAccessControl(){
        $this->ConnectToDB('staff');
        $sessionvar = $this->GetLoginSessionVar();
        $qry = 'select role from '.$this->tablename.' where email_id = "'.$_SESSION[$sessionvar].'"';
        $result = mysql_query($qry, $this->connection);
        $row = mysql_fetch_array($result);
        $usertype = $row['role'];
        return $usertype; 
    }
    
    function SaveToDB($formvars) {
        $this->ConnectToDB('staff');
        if(!$this->IsFieldUnique($formvars,'email_id')){
            $this->HandleError("This email is already registered");
            return false;
        }else{
            $insert_query = 'insert into '.$this->tablename.'(
                `name`,
                ph_no,
                email_id,
                address,
                dept_name,
                dob,
                doj,
                designation,
                role,
                `password`
                )
                values
                (
                "' . $formvars['name'] . '",
                "' . $formvars['ph_no'] . '",
                "' . $formvars['email_id'] . '",
                "' . $formvars['address'] . '",
                "' . $formvars['dept_name'] . '",
                "' . $formvars['dob'] . '",
                "' . $formvars['doj'] . '",
				"' . $formvars['designation'] . '",
                "' . $formvars['role'] . '",
                "' . $formvars['password'] . '"
                )';
            if(!mysql_query( $insert_query ,$this->connection))
            {
                $this->HandleError("Error inserting data to the table\nquery:$insert_query");
                return false;
            }    
        }   
        return true;
    }
    
    function IsFieldUnique($formvars,$fieldname)
    {
        $field_val = $formvars[$fieldname];
        $qry = "select email_id from $this->tablename where $fieldname='".$field_val."'";
        $result = mysql_query($qry,$this->connection);   
        if($result && mysql_num_rows($result) > 0)
        {
            return false;
        }
        return true;
    }
	
    function dbTOcombo($sql){
            $this->ConnectToDB('staff');
            $result = mysql_query( $sql,$this->connection);
            if(! $result ){
                    die('Could not fetch data: ' . mysql_error());
            }
            //$row = mysql_fetch_array($result); 
            return $result;
    }
	
	function RedirectToURL($url)
    {
        header("Location: $url");
        exit;
    }
    
    function GetLoginSessionVar()
    {
        $retvar = md5($this->rand_key);
        $retvar = 'usr_'.substr($retvar,0,10);
        return $retvar;
    }
    
    function HandleError($err)
    {
        $this->error_message .= $err."\r\n";
    }
    
    function GetErrorMessage()
    {
        if(empty($this->error_message))
        {
            return '';
        }
        $errormsg = nl2br(htmlentities($this->error_message));
        return $errormsg;
    }
    
    function SetRandomKey($key){
        $this->rand_key = $key;
    }
    
    function UserFullName()
    {
        return isset($_SESSION['name_of_user'])?$_SESSION['name_of_user']:'';
    }
	function addCSVTodb()
	{ 
		$this->ConnectToDB('performance_param');
		$name=array('A1','A2','A3','A4','A5','A6','A7','A8','A9','A10','A11','A12','A13','A14','A15','A16','A17','B1','B2','B3','B4','C1','C2','C3','C4','C5','D1','D2','D3','D4','D5','D6','D7','D8','D9','D10','D11','D12','E1','E2','E3','E4','E5','F1','F2','F3','F4','F5','F6');
		$result=array();
		foreach($name as $var)
		{
			array_push($result,$_POST[$var]);
		}
		$result=implode(",",$result);
		$insert_query = 'insert into '.$this->tablename.'(input_values) values ("'.$result.'")';
		if(!mysql_query( $insert_query ,$this->connection))
        {
            $this->HandleError("Error inserting data to the table\nquery:$insert_query");
		    die("Error :".$this->error_message);
            return false;
        }      
        return true;
	}
    
    function LogOut()
    {
        session_start();
        
        $sessionvar = $this->GetLoginSessionVar();
        
        $_SESSION[$sessionvar]=NULL;
        
        unset($_SESSION[$sessionvar]);
    }
}

?>
