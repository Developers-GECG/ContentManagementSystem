<?php 
require_once 'config.php';

if(isset($_POST['Submit'])){
   if($functions->addCSVTodb()){
        $url = "success.php";
        header("Location: $url");
        exit;
   }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Bootstrap Admin</title>
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.css">
    
    <link rel="stylesheet" type="text/css" href="stylesheets/theme.css">
    <link rel="stylesheet" href="lib/font-awesome/css/font-awesome.css">

    <script src="lib/jquery-1.7.2.min.js" type="text/javascript"></script>

    <!-- Demo page code -->

    <style type="text/css">
        #line-chart {
            height:300px;
            width:800px;
            margin: 0px auto;
            margin-top: 1em;
        }
        .brand { font-family: georgia, serif; }
        .brand .first {
            color: #ccc;
            font-style: italic;
        }
        .brand .second {
            color: #fff;
            font-weight: bold;
        }
        #tablebg{
            background-color:#d2d2dd;
			color:#000000;
			text-align:center;
        }
		#rowsbg{
			background-color:#d2d2dd;
			color:#000000;
			height:37px;
		}
		#rowbg{
			background-color:#d2d2dd;
			padding-top:5px;
			
		}
    </style>

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="../assets/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="../assets/ico/apple-touch-icon-57-precomposed.png">
  </head>

  <!--[if lt IE 7 ]> <body class="ie ie6"> <![endif]-->
  <!--[if IE 7 ]> <body class="ie ie7 "> <![endif]-->
  <!--[if IE 8 ]> <body class="ie ie8 "> <![endif]-->
  <!--[if IE 9 ]> <body class="ie ie9 "> <![endif]-->
  <!--[if (gt IE 9)|!(IE)]><!--> 
  <body class=""> 
  <!--<![endif]-->
    
    <div class="navbar">
        <div class="navbar-inner">
                <ul class="nav pull-right">
                    
                    <li><a href="#" class="hidden-phone visible-tablet visible-desktop" role="button">Settings</a></li>
                    <li id="fat-menu" class="dropdown">
                        <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="icon-user"></i> Jack Smith
                            <i class="icon-caret-down"></i>
                        </a>

                        <ul class="dropdown-menu">
                            <li><a tabindex="-1" href="#">My Account</a></li>
                            <li class="divider"></li>
                            <li><a tabindex="-1" class="visible-phone" href="#">Settings</a></li>
                            <li class="divider visible-phone"></li>
                            <li><a tabindex="-1" href="sign-in.html">Logout</a></li>
                        </ul>
                    </li>
                    
                </ul>
                <a class="brand" href="index.html"><span class="first">Your</span> <span class="second">Company</span></a>
        </div>
    </div>
    


    
    <div class="sidebar-nav">
        <a href="#dashboard-menu" class="nav-header" data-toggle="collapse"><i class="icon-dashboard"></i>Dashboard</a>
        <ul id="dashboard-menu" class="nav nav-list collapse in">
            <li><a href="index.html">Home</a></li>
            <li ><a href="users.html">Sample List</a></li>
            <li class="active"><a href="user.html">Sample Item</a></li>
            <li ><a href="media.html">Media</a></li>
            <li ><a href="calendar.html">Calendar</a></li>
            
        </ul>

        <a href="#accounts-menu" class="nav-header" data-toggle="collapse"><i class="icon-briefcase"></i>Account<span class="label label-info">+3</span></a>
        <ul id="accounts-menu" class="nav nav-list collapse">
            <li ><a href="sign-in.html">Sign In</a></li>
            <li ><a href="sign-up.html">Sign Up</a></li>
            <li ><a href="reset-password.html">Reset Password</a></li>
        </ul>

        <a href="#error-menu" class="nav-header collapsed" data-toggle="collapse"><i class="icon-exclamation-sign"></i>Error Pages <i class="icon-chevron-up"></i></a>
        <ul id="error-menu" class="nav nav-list collapse">
            <li ><a href="403.html">403 page</a></li>
            <li ><a href="404.html">404 page</a></li>
            <li ><a href="500.html">500 page</a></li>
            <li ><a href="503.html">503 page</a></li>
        </ul>

        <a href="#legal-menu" class="nav-header" data-toggle="collapse"><i class="icon-legal"></i>Legal</a>
        <ul id="legal-menu" class="nav nav-list collapse">
            <li ><a href="privacy-policy.html">Privacy Policy</a></li>
            <li ><a href="terms-and-conditions.html">Terms and Conditions</a></li>
        </ul>

        <a href="help.html" class="nav-header" ><i class="icon-question-sign"></i>Help</a>
        <a href="faq.html" class="nav-header" ><i class="icon-comment"></i>Faq</a>
    </div>
    

    
    <div class="content">
        
        <div class="header">
		<table rows=1>
		<tr><td>
          <img src="images/logo.gif" ></td>
          <td><h1 class="page-title">&nbsp;&nbsp;Commissionerate of Technical Education, Gujarat State</h1>
		  </td>
		</tr>
		</table>
        </div>
        
             <!--   <ul class="breadcrumb">
            <li><a href="index.html">Home</a> <span class="divider">/</span></li>
            <li><a href="users.html">Users</a> <span class="divider">/</span></li>
            <li class="active">User</li>
        </ul>-->

        <div class="container-fluid">
            <div class="row-fluid">
                    
<!--<div class="btn-toolbar">
    <button class="btn btn-primary"><i class="icon-save"></i> Save</button>
    <a href="#myModal" data-toggle="modal" class="btn">Delete</a>
  <div class="btn-group">
  </div>
</div>-->
<div class="well">
 <!--   <ul class="nav nav-tabs">
      <li class="active"><a href="#home" data-toggle="tab">Profile</a></li>
		<li><a href="#profile" data-toggle="tab">Password</a></li>  
    </ul>-->
    <div id="myTabContent" class="tab-content">
      <div class="tab-pane active in" id="home">
        <!--<label>Username</label>
        <input type="text" value="jsmith" class="input-xlarge">
        <label>First Name</label>
        <input type="text" value="John" class="input-xlarge">
        <label>Last Name</label>
        <input type="text" value="Smith" class="input-xlarge">
        <label>Email</label>
        <input type="text" value="jsmith@yourcompany.com" class="input-xlarge">
        <label>Address</label>
        <textarea value="Smith" rows="3" class="input-xlarge">
2817 S 49th
Apt 314
San Jose, CA 95101
        </textarea>
        <label>Time Zone</label>
        <select name="DropDownTimezone" id="DropDownTimezone" class="input-xlarge">
          <option value="-12.0">(GMT -12:00) Eniwetok, Kwajalein</option>
          <option value="-11.0">(GMT -11:00) Midway Island, Samoa</option>
          <option value="-10.0">(GMT -10:00) Hawaii</option>
          <option value="-9.0">(GMT -9:00) Alaska</option>
          <option selected="selected" value="-8.0">(GMT -8:00) Pacific Time (US &amp; Canada)</option>
          <option value="-7.0">(GMT -7:00) Mountain Time (US &amp; Canada)</option>
          <option value="-6.0">(GMT -6:00) Central Time (US &amp; Canada), Mexico City</option>
          <option value="-5.0">(GMT -5:00) Eastern Time (US &amp; Canada), Bogota, Lima</option>
          <option value="-4.0">(GMT -4:00) Atlantic Time (Canada), Caracas, La Paz</option>
          <option value="-3.5">(GMT -3:30) Newfoundland</option>
          <option value="-3.0">(GMT -3:00) Brazil, Buenos Aires, Georgetown</option>
          <option value="-2.0">(GMT -2:00) Mid-Atlantic</option>
          <option value="-1.0">(GMT -1:00 hour) Azores, Cape Verde Islands</option>
          <option value="0.0">(GMT) Western Europe Time, London, Lisbon, Casablanca</option>
          <option value="1.0">(GMT +1:00 hour) Brussels, Copenhagen, Madrid, Paris</option>
          <option value="2.0">(GMT +2:00) Kaliningrad, South Africa</option>
          <option value="3.0">(GMT +3:00) Baghdad, Riyadh, Moscow, St. Petersburg</option>
          <option value="3.5">(GMT +3:30) Tehran</option>
          <option value="4.0">(GMT +4:00) Abu Dhabi, Muscat, Baku, Tbilisi</option>
          <option value="4.5">(GMT +4:30) Kabul</option>
          <option value="5.0">(GMT +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent</option>
          <option value="5.5">(GMT +5:30) Bombay, Calcutta, Madras, New Delhi</option>
          <option value="5.75">(GMT +5:45) Kathmandu</option>
          <option value="6.0">(GMT +6:00) Almaty, Dhaka, Colombo</option>
          <option value="7.0">(GMT +7:00) Bangkok, Hanoi, Jakarta</option>
          <option value="8.0">(GMT +8:00) Beijing, Perth, Singapore, Hong Kong</option>
          <option value="9.0">(GMT +9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk</option>
          <option value="9.5">(GMT +9:30) Adelaide, Darwin</option>
          <option value="10.0">(GMT +10:00) Eastern Australia, Guam, Vladivostok</option>
          <option value="11.0">(GMT +11:00) Magadan, Solomon Islands, New Caledonia</option>
          <option value="12.0">(GMT +12:00) Auckland, Wellington, Fiji, Kamchatka</option>
    </select>
    </form>-->
	    <form name="form1" action="user.php" method="POST">
<table width="950" cellspacing="0" border="1" bordercolor="#000000">

<tr>
  <td colspan="3"><div align="center"><strong><font color="#964836"> Commissionerate of Technical Education, Gujarat State<br />
    Faculty Evaluation</font> <font color="red">2013-14</font></strong></div></td>
</tr>
<tr >
  <td height="38" colspan="2"><font color="#191970">Name of Institute :</font></td>
  <td width="793"><input type="text" name="institute_name" /></td>
  </tr>
<tr>
  <td height="38" colspan="2"><font color="#191970">Name of Department :</font></td>
  <td><input type="text" name="dept_name" /></td>
  </tr>
<tr>
  <td height="38" colspan="2"><font color="#191970">Name of Faculty :</font></td>
  <td><input type="text" name="faculty_name" /></td>
  </tr>
<tr>
  <td height="38" colspan="2"><font color="#191970">Designation of Faculty :</font></td>
  <td><input type="text" name="faculty_designation" /></td>
  </tr>
<tr>
  <td height="38" colspan="2"><font color="#191970">Duration of Evaluation :</font></td>
  <td><input type="text" name="duration" /></td>
  </tr>
</table>
<table width="950" cellspacing="0" border="1" bordercolor="#000000" >
<tr id="tablebg" >
<td height="47" colspan="3" > <strong>SR No.</strong></p></td>
<td width="747"> <strong>Criteria for Academic Performance Index</strong></td>
<td width="94"> <strong>Faculty Response</strong></td>
</tr>
<tr id="rowsbg">
  <td colspan="3" align="center"><strong>A</strong></td>
  <td ><strong>Academic domain(70%)</strong></font></td>
  <td >&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">1</td>
  <td>Prepared and implemented lesson planning for each allotted theory subject ? (Y/N)</td>
  <td id="rowbg"><select name="A1" >
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">2</td>
  <td>Students informed about lesson planning in advance ? (Y/N)</td>
  <td id="rowbg"><select name="A2">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">3</td>
  <td>No. of days attended &amp; delivered teaching duties ? </td>
  <td id="rowbg">
      <select name="A3">
<option  value="0" >N/A</option> 
<?php
  for($i=0;$i<100;$i++){
    echo "<option value=$i> $i </option>";
  }
?>
</select>
  </td>
</tr>
<tr>
  <td colspan="3" id="tablebg">4</td>
  <td>Total number of Lectures Dilevered : Planned  (eg. 10:8)</td>
  <td id="rowbg"><input type="text" name="A4" /></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">5</td>
  <td>Total number of Practicals/Tutorials Dilevered : Planned (eg. 10:6)</td>
  <td id="rowbg"><input type="text" name="A5"/></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">6</td>
  <td>% Syllabus actually covered ? Specify reason for short fall of syllabus in space below:</td>
  <td id="rowbg"><input type="text" name="A6" /></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">&nbsp;</td>
  <td><textarea rows="5" cols="10"></textarea></td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">7</td>
  <td>Used Audio Visual aid during delivery of lecturers? (Y/N)</td>
  <td id="rowbg"><select name="A7">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">8</td>
  <td>Usage of e-resourses during the term in Hrs. for lecture/lab preparation (Y/N)</td>
  <td id="rowbg"><select name="A8">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">9</td>
  <td>Use of Internet to inform student related to assignment, attandance, feedback, etc. (Y/N)</td>
  <td id="rowbg"><select name="A9">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">10</td>
  <td>No. of online lectures in related subjects shown to students </td>
  <td id="rowbg"><select name="A10">
    <option>NA</option>
    <?php
      for($i=0;$i<100;$i++){
        echo "<option value=$i> $i </option>";
      }
    ?>
	</select>
</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">11</td>
  <td>Student attendance record entered, updated and maintained regularly ? (Y/N)</td>
  <td id="rowbg"><select name="A11">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">12</td>
  <td>No. of LR Prepared for lecture/laboratory work?</td>
  <td id="rowbg"><select name="A12">
    <option>NA</option>
    <?php
      for($i=0;$i<100;$i++){
        echo "<option value=$i> $i </option>";
      }
    ?>
	</select>
    </td>
</tr>
<tr>
  <td colspan="3" id="tablebg">13</td>
  <td>No. of expert lecture arranged for your allotted subject for recent updation in the subject ? </td>
  <td id="rowbg"><select name="A13">
    <option>NA</option>
    <?php
      for($i=0;$i<100;$i++){
        echo "<option value=$i> $i </option>";
      }
    ?>
	</select>
    </td>
</tr>
<tr>
  <td colspan="3" id="tablebg">14</td>
  <td>No. of laboratory development/upgradation/modernization</td>
  <td id="rowbg"><select name="A14">
    <option>NA</option>
    <?php
      for($i=0;$i<100;$i++){
        echo "<option value=$i> $i </option>";
      }
    ?>
	</select>
    </td>
</tr>
<tr>
  <td colspan="3" id="tablebg">15</td>
  <td>No. of new experimental set-ups in laboratory </td>
  <td id="rowbg"><select name="A15">
    <option>NA</option>
    <?php
      for($i=0;$i<100;$i++){
        echo "<option value=$i> $i </option>";
      }
    ?>
	</select>
    </td>
</tr>
<tr>
  <td colspan="3" id="tablebg">16</td>
  <td>No. of U.G. students guided in their project work like IDP/UDP/Industry </td>
  <td id="rowbg"><select name="A16">
    <option>NA</option>
    <?php
      for($i=0;$i<100;$i++){
        echo "<option value=$i> $i </option>";
      }
    ?>
	</select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">17</td>
  <td>No. of site visit/industrial visit arranged related to the subject </td>
  <td id="rowbg"><select name="A17">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr id="rowsbg" >
  <td colspan="3" align="center"><strong>B</strong></td>
  <td ><strong>Institutional domain (10%)</strong></td>
  <td >&nbsp;</td>
</tr>
  <td colspan="3" id="tablebg">1</td>
  <td>Specify nature and no. of duties alloted by department besides teaching(note: use textbox below)</td>
  <td id="rowbg"><select name="B1">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3"id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">1.1</td>
  <td>Specify outcomes from the duties allotted by department</td>
  <td id="rowbg"><select name="B2">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">2</td>
  <td>Specify nature and no. of duties allotted by institute to work at central level, other than teaching</td>
  <td id="rowbg"><select name="B3">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3"id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">2.1</td>
  <td>Specify outcomes from duties allotted by institute to work at central level</td>
  <td id="rowbg"><select name="B4">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr id="rowsbg">
  <td colspan="3" align="center"><strong>C</strong></td>
  <td ><strong>Career advancement (5 %)</strong></td>
  <td >&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">1</td>
  <td>No. of training programmes  applied for </td>
  <td id="rowbg"><select name="C1">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">2</td>
  <td>No. of training programmes attended within institute/state</td>
  <td id="rowbg"><select name="C2">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">3</td>
  <td>No. of training programmes attended outside State/country</td>
  <td id="rowbg"><select name="C3">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">4</td>
  <td>No. of Expert lectures given at Trainings/ Workshops; along with No. of Participants in each</td>
  <td id="rowbg"><select name="C4">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">5</td>
  <td>Member of professional bodies </td>
  <td id="rowbg"><select name="C5">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr id="rowsbg">
  <td colspan="3" align="center"><strong>D</strong></td>
  <td ><strong>PG techning/Research / Publication/Consultancy (10 %) </strong></td>
  <td >&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">1</td>
  <td>No. of post graduate classes taught in (where ever applicable) </td>
  <td id="rowbg"><select name="D1">
    <option>NA</option>
    <?php
      for($i=0;$i<100;$i++){
        echo "<option value=$i> $i </option>";
      }
    ?>
	</select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">2</td>
  <td>No. of post graduate students guided in their thesis work (where ever applicable) </td>
  <td id="rowbg"><select name="D2">
    <option>NA</option>
    <?php
      for($i=0;$i<100;$i++){
        echo "<option value=$i> $i </option>";
      }
    ?>
	</select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">3</td>
  <td>No. of Ph. D students guided (where ever applicable) </td>
  <td id="rowbg"><select name="D3">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">4</td>
  <td>No. of Papers published/presented  at conferences ? State or National level? </td>
  <td id="rowbg"><select name="D4">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">5</td>
  <td>No. of papers  published in National journal: Authors, Title, Year and Journal </td>
  <td id="rowbg"><select name="D5">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">6</td>
  <td>No. of papers  published in International journal: Authors, Title, Year and Journal </td>
  <td id="rowbg"><select name="D6">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">7</td>
  <td>Any Recognition/award received for paper/ research/ expert talk? (Y/N/NA)</td>
  <td id="rowbg"><select name="D7">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">8</td>
  <td>Any Patents received/ Applied for ? If yes, Give details (Y/N/NA)</td>
  <td id="rowbg"><select name="D8">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">9</td>
  <td>Any Technical books published ? If yes, Give details of ISBN,ISSN etc. (Y/N/NA)</td>
  <td id="rowbg"><select name="D9">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3"id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">10</td>
  <td>No. of Consultancy projects undertaken/participated with amount (Y/N/NA)</td>
  <td id="rowbg"><select name="D10">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">11</td>
  <td>Any Research grant received from AICTE/UGC/OTHER ? (Y/N/NA)</td>
  <td id="rowbg"><select name="D11">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">12</td>
  <td>Any research collabration with national or international institutes ? (Y/N/NA)</td>
  <td id="rowbg"><select name="D12">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr id="rowsbg">
  <td colspan="3" align="center"><strong>E</strong></td>
  <td ><strong>Activities/duties performed outside institute (5 %)</strong><</td>
  <td >&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">1</td>
  <td>Specify duties performed at University level</td>
  <td id="rowbg"><select name="E1">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3"id="tablebg">2</td>
  <td>Specify duties performed at Govt. level </td>
  <td id="rowbg"><select name="E2">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">3</td>
  <td>Duties as Member in other institute/university/professional bodies</td>
  <td id="rowbg"><select name="E3">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">4</td>
  <td>Specify Social or Community activities undertaken </td>
  <td id="rowbg"><select name="E4">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">5</td>
  <td>Recognition/ Acknowledgements received for social causes</td>
  <td id="rowbg"><select name="E5">
    <option>Yes</option>
    <option>No</option>
  </select></td>
</tr>
<tr id="rowsbg">
  <td colspan="3" align="center"><strong>F</strong></td>
  <td ><strong>Faculty Feedback ( 0 to 5)</strong></td>
  <td >&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">1</td>
  <td>Regularity of Head of Department </td>
  <td id="rowbg"><select name="F1">
    <option>NA</option>
    <?php
      for($i=0;$i<100;$i++){
        echo "<option value=$i> $i </option>";
      }
    ?>
	</select>
    </td>
</tr>
<tr>
  <td colspan="3" id="tablebg">2</td>
  <td>Academic and Administrative Leadership Quality of HOD</td>
  <td id="rowbg"><select name="F2">
    <option>NA</option>
    <?php
      for($i=0;$i<100;$i++){
        echo "<option value=$i> $i </option>";
      }
    ?>
	</select>
</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">3</td>
  <td>Leadership Quality of Principal</td>
  <td id="rowbg"><select name="F3">
    <option>NA</option>
    <?php
      for($i=0;$i<100;$i++){
        echo "<option value=$i> $i </option>";
      }
    ?>
	</select>
    </td>
</tr>
<tr>
  <td colspan="3" id="tablebg">4</td>
  <td>Students Regularity and attendance attitude</td>
  <td id="rowbg"><select name="F4">
    <option>NA</option>
    <?php
      for($i=0;$i<100;$i++){
        echo "<option value=$i> $i </option>";
      }
    ?>
	</select>
    </td>
</tr>
<tr>
  <td colspan="3" id="tablebg">5</td>
  <td>Admin facilities and availability of academic resources</td>
  <td id="rowbg"><select name="F5">
    <option>NA</option>
    <?php
      for($i=0;$i<100;$i++){
        echo "<option value=$i> $i </option>";
      }
    ?>
	</select>
    </td>
</tr>
<tr>
  <td colspan="3" id="tablebg">6</td>
  <td>Explanation (if any) in single bullet points limited to 5 bullets</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg"&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">7</td>
  <td>Time taken to fill data</td>
  <td id="rowbg"><input type="text" name="F6"/></td>
</tr>
<tr>
  <td colspan="3" id="tablebg">8</td>
  <td>Difficulties faced while filling data</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">9</td>
  <td>Suggesstion to Add/Delete any Parameter</td>
  <td id="rowbg">&nbsp;</td>
</tr>
<tr>
  <td colspan="3" id="tablebg">&nbsp;</td>
  <td>&nbsp;</td>
  <td id="rowbg">&nbsp;</td>
</tr>

</table> 
<input type='submit' name='Submit' value='Submit' class="btn btn-primary pull-right">  
  <!-- 
<table width="1000">
    <tr><td>&nbsp;</td></tr>
        <tr height="25">
          <td width="865">&nbsp;</td>
		  <input type='submit' name='Submit' value='Register' class="btn btn-primary pull-right">
    <td width="73"><button class="btn btn-primary pull-right" ><i class="icon-save"></i> Submit</button></td>
        </tr>
      </table>  -->
	  </form>


      </div>
      <div class="tab-pane fade" id="profile">
    <form id="tab2">
        <label>New Password</label>
        <input type="password" class="input-xlarge">
        <div>
            <button class="btn btn-primary">Update</button>
        </div>
    </form>
      </div>
  </div>

</div>

<div class="modal small hide fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Delete Confirmation</h3>
  </div>
  <div class="modal-body">
    
    <p class="error-text"><i class="icon-warning-sign modal-icon"></i>Are you sure you want to delete the user?</p>
  </div>
  <div class="modal-footer">
    <button class="btn" data-dismiss="modal" aria-hidden="true">Cancel</button>
    <button class="btn btn-danger" data-dismiss="modal">Delete</button>
  </div>
</div>


                    
                    <footer>
                        <hr>

                        <!-- Purchase a site license to remove this link from the footer: http://www.portnine.com/bootstrap-themes -->
                        <p class="pull-right">A <a href="http://www.portnine.com/bootstrap-themes" target="_blank">Free Bootstrap Theme</a> by <a href="http://www.portnine.com" target="_blank">Portnine</a></p>

                        <p>&copy; 2012 <a href="http://www.portnine.com" target="_blank">Portnine</a></p>
                    </footer>
                    
            </div>
        </div>
    </div>
    

  <script src="lib/bootstrap/js/bootstrap.js"></script>
    <script type="text/javascript">
        $("[rel=tooltip]").tooltip();
        $(function() {
            $('.demo-cancel-click').click(function(){return false;});
        });
    </script>

  </body>
</html>


